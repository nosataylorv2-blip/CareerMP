load('careerMPEnabler')
setExtensionUnloadMode('careerMPEnabler', 'manual')

load('careerMPUIApps')
setExtensionUnloadMode('careerMPUIApps', 'manual')

load('careerMPPlayerPayments')
setExtensionUnloadMode('careerMPPlayerPayments', 'manual')

load('careerMPPerPartPaint')
setExtensionUnloadMode('careerMPPerPartPaint', 'manual')

load('/career/careerMP')
setExtensionUnloadMode('/career/careerMP', 'manual')
