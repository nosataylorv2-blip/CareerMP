
-- Career repairs, tuning and part changes replace the existing vehicle in
-- place. BeamMP can poll that replacement before onVehicleReady or extension
-- lifecycle hooks run, so its vehicle modules must load while this automatic
-- extension itself is being evaluated.
extensions.loadModulesInDirectory('lua/vehicle/extensions/BeamMP')

local M = {}

local function onVehicleReady()
	obj:queueGameEngineLua("careerMPEnabler.onVehicleReady(" .. obj:getID() .. ") ")
	obj:queueGameEngineLua("careerMPPerPartPaint.onVehicleReady(" .. obj:getID() .. ") ")
end

local function setGhost(enabled)
	obj:setGhostEnabled(enabled)
end

M.setGhost = setGhost

M.onVehicleReady = onVehicleReady

return M
