--CareerMP (CLIENT) by Dudekahedron, 2026

local M = {}

--Setup

local nickname = MPConfig.getNickname()

local blockedInputActions = {}

local clientConfig

local function getClientConfig()
	return clientConfig
end

local careerMPActive = false
local syncRequested = false
local pendingTutorialRestore = nil
local tutorialWorldStateFile = "/career/tutorialWorldState.json"

local originalMPOnUpdate
local originalGetDriverData
local originalMissionStartWithFade
local missionStartWrapper

-- Drag missions can retain the pre-stash vehicle's playable flag after BeamMP
-- hands control back to the career vehicle. The race still runs, but BeamNG's
-- stock display module then suppresses its staging and stopping instructions.
-- Restore only those mission messages for the vehicle the local player is
-- actually controlling; freeroam keeps using the stock drag display path.
local function showLocalDragMissionMessage(vehId, message, duration)
	if not careerMPActive or not gameplay_drag_core or not gameplay_drag_core.getGameplayContext then return end
	if gameplay_drag_core.getGameplayContext() == "freeroam" then return end
	if vehId ~= be:getPlayerVehicleID(0) then return end
	local dragData = gameplay_drag_core.getData and gameplay_drag_core.getData() or nil
	local racer = dragData and dragData.racers and dragData.racers[vehId] or nil
	if racer and racer.isPlayable then return end
	ui_appContainers.showApp('topCenter', 'flashMessage')
	guihooks.trigger('TopCenterAppsFlashMessage', {msg = message, ttl = duration or 5, big = false})
	guihooks.trigger('ScenarioFlashMessage', {msg = message, ttl = duration or 5, big = false})
end

local function preStageLightOn(vehId)
	showLocalDragMissionMessage(vehId, "Pre-stage", 5)
end

local function stageLightOn(vehId)
	showLocalDragMissionMessage(vehId, "Stage", 5)
end

local function stoppingVehicleDrag(vehId)
	showLocalDragMissionMessage(vehId, "Stop the vehicle!", 5)
end

local function onDragRacersSetup(dragData)
	if not careerMPActive or not dragData then return end
	local context = dragData.context
	if not context and gameplay_drag_core and gameplay_drag_core.getGameplayContext then
		context = gameplay_drag_core.getGameplayContext()
	end
	if context == "freeroam" then return end
	local playerVehicleId = be:getPlayerVehicleID(0)
	if playerVehicleId and dragData.racers and dragData.racers[playerVehicleId] then
		dragData.racers[playerVehicleId].isPlayable = true
	end
end

local inComputerMenus = false

-- BeamNG 0.39 takes the career vehicle's part-condition snapshot after the
-- mission setup has stashed it. BeamMP vehicles no longer answer the bridge
-- ping while stashed, leaving the mission loading screen up for 120 seconds.
-- Take the same snapshot while the local vehicle is still active, then skip
-- only the later duplicate snapshot task.
local function patchMissionStart()
	local manager = extensions.gameplay_missions_missionManager or gameplay_missions_missionManager
	if not manager or not manager.startWithFade then return end
	if missionStartWrapper and manager.startWithFade == missionStartWrapper then return end

	originalMissionStartWithFade = manager.startWithFade
	local stockStartWithFade = originalMissionStartWithFade
	missionStartWrapper = function(mission, userSettings, startingOptions)
		if careerMPActive then
			local currentVehicle = career_modules_inventory and career_modules_inventory.getCurrentVehicle
				and career_modules_inventory.getCurrentVehicle()
			local vehObj = currentVehicle and getPlayerVehicle(0) or nil
			if vehObj and vehObj.JBeam ~= 'unicycle' then
				core_vehicleBridge.executeAction(vehObj, 'createPartConditionSnapshot', 'beforeMission')
				core_vehicleBridge.executeAction(vehObj, 'setPartConditionResetSnapshotKey', 'beforeMission')
				mission._partConditionSnapshotTaken = true
				log('I', 'careerMP.missions', 'Captured pre-mission vehicle condition before BeamMP stash')
			end
			local copiedOptions = {}
			for key, value in pairs(startingOptions or {}) do copiedOptions[key] = value end
			copiedOptions.skipPartConditionSnapshot = true
			startingOptions = copiedOptions
			log('I', 'careerMP.missions', 'Disabled unsafe post-stash condition snapshot')
		end
		return stockStartWithFade(mission, userSettings, startingOptions)
	end

	manager.start = missionStartWrapper
	manager.startWithFade = missionStartWrapper
	log('I', 'careerMP.missions', 'Installed mission start compatibility wrapper')
end

--Settings

local userTrafficSettings = {}
local careerMPTrafficSettings = {}

local userGameplaySettings = {}
local careerMPGameplaySettings = {}

local function getUserTrafficSettings()
	userTrafficSettings.trafficSmartSelections = settings.getValue('trafficSmartSelections')
	userTrafficSettings.trafficSimpleVehicles = settings.getValue('trafficSimpleVehicles')
	userTrafficSettings.trafficAllowMods = settings.getValue('trafficAllowMods')
end

local function setTrafficSettings(trafficSettings)
	for setting, value in pairs(trafficSettings) do
		settings.setValue(setting, value)
	end
end

local function getUserGameplaySettings()
	userGameplaySettings.simplifyRemoteVehicles = settings.getValue("simplifyRemoteVehicles")
	userGameplaySettings.spawnVehicleIgnitionLevel = settings.getValue("spawnVehicleIgnitionLevel")
	userGameplaySettings.skipOtherPlayersVehicles = settings.getValue("skipOtherPlayersVehicles")
end

local function setGameplaySettings(gameplaySettings)
	for setting, value in pairs(gameplaySettings) do
		settings.setValue(setting, value)
	end
end

--Hidden Nametags by Vehicle Model

local hiddens = {
	anticut = "anticut",
	ball = "ball",
	barrels = "barrels",
	barrier = "barrier",
	barrier_plastic = "barrier_plastic",
	blockwall = "blockwall",
	bollard = "bollard",
	boxutility = "boxutility",
	boxutility_large = "boxutility_large",
	cannon = "cannon",
	caravan = "caravan",
	cardboard_box = "cardboard_box",
	cargotrailer = "cargotrailer",
	chair = "chair",
	christmas_tree = "christmas_tree",
	cones = "cones",
	containerTrailer = "containerTrailer",
	couch = "couch",
	crowdbarrier = "crowdbarrier",
	delineator = "delineator",
	dolly = "dolly",
	dryvan = "dryvan",
	engine_props = "engine_props",
	flail = "flail",
	flatbed = "flatbed",
	flipramp = "flipramp",
	frameless_dump = "frameless_dump",
	fridge = "fridge",
	gate = "gate",
	haybale = "haybale",
	inflated_mat = "inflated_mat",
	kickplate = "kickplate",
	large_angletester = "large_angletester",
	large_bridge = "large_bridge",
	large_cannon = "large_cannon",
	large_crusher = "large_crusher",
	large_hamster_wheel = "large_hamster_wheel",
	large_roller = "large_roller",
	large_spinner = "large_spinner",
	large_tilt = "large_tilt",
	large_tire = "large_tire",
	log_trailer = "log_trailer",
	logs = "logs",
	mattress = "mattress",
	metal_box = "metal_box",
	metal_ramp = "metal_ramp",
	piano = "piano",
	porta_potty = "porta_potty",
	pressure_ball = "pressure_ball",
	rallyflags = "rallyflags",
	rallysigns = "rallysigns",
	rallytape = "rallytape",
	roadsigns = "roadsigns",
	rocks = "rocks",
	rollover = "rollover",
	roof_crush_tester = "roof_crush_tester",
	sawhorse = "sawhorse",
	shipping_container = "shipping_container",
	simple_traffic = "simple_traffic",
	spikestrip = "spikestrip",
	steel_coil = "steel_coil",
	streetlight = "streetlight",
	suspensionbridge = "suspensionbridge",
	tanker = "tanker",
	testroller = "testroller",
	tiltdeck = "tiltdeck",
	tirestacks = "tirestacks",
	tirewall = "tirewall",
	trafficbarrel = "trafficbarrel",
	trampoline = "trampoline",
	trashbin = "trashbin",
	tsfb = "tsfb",
	tub = "tub",
	tube = "tube",
	tv = "tv",
	wall = "wall",
	weightpad = "weightpad",
	woodcrate = "woodcrate",
	woodplanks = "woodplanks",
}

--Vehicles and part paints

local function rxCareerVehSync(data)
	if data ~= "null" then
		local vehicleStates = jsonDecode(data)
		local vehicles = MPVehicleGE.getVehicles()
		for serverVehicleID, state in pairs(vehicleStates) do
			if vehicles[serverVehicleID] then
				local gameVehicleID = vehicles[serverVehicleID].gameVehicleID
				if gameVehicleID ~= -1 then
					if not MPVehicleGE.isOwn(gameVehicleID) then
						if not state.active then
							be:getObjectByID(gameVehicleID):setActive(0)
							vehicles[serverVehicleID].hideNametag = true
						else
							be:getObjectByID(gameVehicleID):setActive(1)
							if hiddens[vehicles[serverVehicleID].jbeam] then
								vehicles[serverVehicleID].hideNametag = true
							else
								vehicles[serverVehicleID].hideNametag = false
							end
						end
					end
				end
			end
		end
	end
end

local function getKnownServerVehicleID(gameVehicleID)
	if not gameVehicleID or not MPVehicleGE or not MPVehicleGE.getVehicles then return nil end
	for serverVehicleID, vehicleData in pairs(MPVehicleGE.getVehicles()) do
		if vehicleData.gameVehicleID == gameVehicleID then
			return serverVehicleID
		end
	end
	return nil
end

local function onVehicleActiveChanged(gameVehicleID, active)
	if gameVehicleID then
		if MPVehicleGE.isOwn(gameVehicleID) then
			local serverVehicleID = getKnownServerVehicleID(gameVehicleID)
			if serverVehicleID then
				local data = {}
				data.active = active
				data.serverVehicleID = serverVehicleID
				TriggerServerEvent("careerVehicleActiveHandler", jsonEncode(data))
			end
		else
			TriggerServerEvent("careerVehSyncRequested", "")
		end
	end
end

local function isLocalCareerTraffic(gameVehicleID, veh)
	if not veh or veh:isPlayerControlled() then
		return false
	end
	if veh.JBeam == "simple_traffic" then
		return true
	end
	local trafficData = gameplay_traffic and gameplay_traffic.getTrafficData and gameplay_traffic.getTrafficData()
	-- Career also registers the player's current vehicle in the traffic table
	-- with AI disabled. Checking for table membership alone therefore mistakes
	-- part-shopping/tuning replacements for traffic and leaves a duplicate.
	local trafficVehicle = trafficData and trafficData[gameVehicleID]
	return trafficVehicle and trafficVehicle.isAi == true
end

local function onVehicleSpawned(gameVehicleID)
	if gameVehicleID then
		local veh = be:getObjectByID(gameVehicleID)
		-- Career traffic is local simulation state, not a player-owned vehicle.
		-- Sending it through BeamMP consumes the player's vehicle quota and can
		-- cause an endless spawn/remove loop when the server rejects the excess.
		if isLocalCareerTraffic(gameVehicleID, veh) then
			return
		end
		if veh then
			veh:queueLuaCommand('careerMPEnabler.onVehicleReady()')
		end
		if not MPVehicleGE.isOwn(gameVehicleID) then
			TriggerServerEvent("careerVehSyncRequested", "")
		end
	end
end

local function onVehicleReady(gameVehicleID)
	-- Career creates local preview, traffic and mission vehicles that are not
	-- registered with BeamMP. Looking up those IDs through BeamMP logs an error
	-- and can leak local career lifecycle events into multiplayer handling.
	local serverVehicleID = getKnownServerVehicleID(gameVehicleID)
	if serverVehicleID then
		local veh = be:getObjectByID(gameVehicleID)
		if veh then
			if not MPVehicleGE.isOwn(gameVehicleID) then
				local vehicles = MPVehicleGE.getVehicles()
				if clientConfig then
					if veh.JBeam == "unicycle" then
						veh:queueLuaCommand('careerMPEnabler.setGhost(' .. tostring(clientConfig.remoteUnicycleGhost) .. ')')
					else
						veh:queueLuaCommand('careerMPEnabler.setGhost(' .. tostring(clientConfig.remoteVehicleGhost) .. ')')
					end
				end
				if hiddens[veh.JBeam] then
					vehicles[serverVehicleID].hideNametag = true
				else
					vehicles[serverVehicleID].hideNametag = false
				end
			elseif clientConfig and veh.JBeam == "unicycle" then
				veh:queueLuaCommand('careerMPEnabler.setGhost(' .. tostring(clientConfig.localUnicycleGhost) .. ')')
			end
			veh:setField('renderDistance', '', 1610)
		end
	end
end

local function applyGhostSettings()
	if not clientConfig or not MPVehicleGE or not MPVehicleGE.getVehicles then return end
	for _, vehicle in pairs(MPVehicleGE.getVehicles()) do
		local gameVehicleID = vehicle.gameVehicleID
		local veh = gameVehicleID and be:getObjectByID(gameVehicleID) or nil
		if veh then
			if vehicle.isLocal then
				if veh.JBeam == "unicycle" then
					veh:queueLuaCommand('careerMPEnabler.setGhost(' .. tostring(clientConfig.localUnicycleGhost) .. ')')
				end
			elseif veh.JBeam == "unicycle" then
				veh:queueLuaCommand('careerMPEnabler.setGhost(' .. tostring(clientConfig.remoteUnicycleGhost) .. ')')
			else
				veh:queueLuaCommand('careerMPEnabler.setGhost(' .. tostring(clientConfig.remoteVehicleGhost) .. ')')
			end
		end
	end
end

local function onVehicleSwitched(oldGameVehicleID, newGameVehicleID)
	local newVeh = be:getObjectByID(newGameVehicleID)
	local oldVeh = be:getObjectByID(oldGameVehicleID)
	if newVeh then
		if hiddens[newVeh.JBeam] then
			if not MPVehicleGE.isOwn(newGameVehicleID) then
				be:enterNextVehicle(0, 1)
			end
		end
		if newVeh.JBeam == "unicycle" then
			if inComputerMenus then
				gameplay_walk.setWalkingMode(false)
				be:enterVehicle(0, oldVeh)
			end
		end
	end
end

--Traffic Signals and Cameras

local function onSpeedTrapTriggered(speedTrapData, playerSpeed, overSpeed)
	if MPVehicleGE.isOwn(speedTrapData.subjectID) then
		local veh = be:getObjectByID(speedTrapData.subjectID)
		local highscore, leaderboard = gameplay_speedTrapLeaderboards.addRecord(speedTrapData, playerSpeed, overSpeed, veh)
		speedTrapData.licensePlate = veh:getDynDataFieldbyName("licenseText", 0) or "Illegible"
		speedTrapData.vehicleModel = core_vehicles.getModel(veh.JBeam).model.Name
		speedTrapData.playerSpeed = playerSpeed
		speedTrapData.overSpeed = overSpeed
		speedTrapData.highscore = highscore
		speedTrapData.leaderboard = leaderboard
		TriggerServerEvent("speedTrap", jsonEncode( speedTrapData ) )
	end
end

local function onRedLightCamTriggered(redLightData, playerSpeed)
	if MPVehicleGE.isOwn(redLightData.subjectID) then
		local veh = be:getObjectByID(redLightData.subjectID)
		redLightData.licensePlate = veh:getDynDataFieldbyName("licenseText", 0) or "Illegible"
		redLightData.vehicleModel = core_vehicles.getModel(veh.JBeam).model.Name
		redLightData.playerSpeed = playerSpeed
		TriggerServerEvent("redLight", jsonEncode( redLightData ) )
	end
end

local function rxTrafficSignalTimer(data)
	core_trafficSignals.setTimer(tonumber(data))
end

--Garage / Office Computer Handling

local function computerMenuHandler(targetVehicleID)
	if targetVehicleID then
		local veh = be:getObjectByID(targetVehicleID)
		if veh then
			if veh.JBeam ~= "unicycle" then
				if gameplay_walk.isWalking() then
					gameplay_walk.getInVehicle(veh)
				else
					be:enterVehicle(0, veh)
				end
				inComputerMenus = true
			end
		end
	end
end

local function onComputerOpened()
	if inComputerMenus then
		inComputerMenus = false
	end
end

--Patch BeamMP behavior and topBar

local function patchTopBar()
	if not ui_topBar then
		log('I', 'careerMP', 'Legacy ui_topBar is unavailable; skipping top-bar customization')
		return
	end
	local entries = ui_topBar.getEntries()
	ui_topBar.removeEntry("environment")
	ui_topBar.removeEntry("mods")
	ui_topBar.removeEntry("vehicleconfig")
	ui_topBar.removeEntry("vehicles")
	entries = ui_topBar.getEntries()
	ui_topBar.updateEntries(entries)
	ui_topBar.updateVisibleItems()
end

local function modifiedGetDriverData(veh)
	if not veh then return nil end
	local caller = debug.getinfo(2).name
	if caller and caller == "getDoorsidePosRot" and veh.mpVehicleType and veh.mpVehicleType == 'R' then
		local id, right = core_camera.getDriverDataById(veh and veh:getID())
		return id, not right
	end
	return core_camera.getDriverDataById(veh and veh:getID())
end

local function modifiedOnUpdate(dt)
	if MPCoreNetwork and MPCoreNetwork.isMPSession() then
		if core_camera.getDriverData ~= modifiedGetDriverData then
			log('W', 'onUpdate', 'Setting modifiedGetDriverData')
			originalGetDriverData = core_camera.getDriverData
			core_camera.getDriverData = modifiedGetDriverData
		end
		if worldReadyState == 0 then
			serverConnection.onCameraHandlerSetInitial()
			extensions.hook('onCameraHandlerSet')
		end
	end
end

local originalMPVehicleOnSpawned
local originalMPPositionSetPing
local pendingVehicleSpawnChecks = {}

local function isDeferredLocalCareerVehicle(gameVehicleID, veh)
	if isLocalCareerTraffic(gameVehicleID, veh) then
		return true
	end
	if not veh then return false end
	local vehicleGroup = veh:getDynDataFieldbyName('vehicleGroup', 0)
	-- BeamNG 0.39 assigns this just after onVehicleSpawned. Career traffic,
	-- parking and mission grids are local simulation and must never be sent as
	-- player vehicles to BeamMP.
	return vehicleGroup ~= nil and vehicleGroup ~= ''
end

local function isLocalTutorialVehicle(veh)
	if not veh or veh.mpVehicleType == 'R' then return false end
	local career = career_career or extensions.career_careerMP
	return career and career.tutorialEnabled == true
end

local function prepareLocalVehicleForBeamMP(veh)
	if not veh or veh.mpVehicleType == 'R' then return end
	-- BeamMP sends edit data before loading its vehicle extensions when Career
	-- replaces the walking vehicle with an owned car. Queue the module load first
	-- so the replacement cannot be queried while its VE globals are still nil.
	veh:queueLuaCommand("extensions.loadModulesInDirectory('lua/vehicle/extensions/BeamMP')")
end

local function careerMPVehicleSpawnFilter(gameVehicleID)
	local veh = be:getObjectByID(gameVehicleID)
	-- APM onboarding owns its walking placeholder and starter car. They must
	-- remain local or BeamMP can relocate/remove them before the player reaches
	-- the first tutorial objective.
	if isLocalTutorialVehicle(veh) then
		log('D', 'careerMP.tutorial', 'Keeping onboarding vehicle local: ' .. tostring(gameVehicleID))
		return
	end
	if isLocalCareerTraffic(gameVehicleID, veh) then
		log('D', 'careerMP.traffic', 'Keeping Career AI traffic local: ' .. tostring(gameVehicleID))
		return
	end
	-- MultiSpawn sets its vehicleGroup marker after the spawn callback. Defer
	-- unoccupied local vehicles briefly so that marker can be observed. Remote
	-- BeamMP vehicles are already marked and must be handled immediately.
	if veh and not veh:isPlayerControlled() and veh.mpVehicleType ~= 'R' then
		pendingVehicleSpawnChecks[gameVehicleID] = 2
		return
	end
	if originalMPVehicleOnSpawned then
		prepareLocalVehicleForBeamMP(veh)
		return originalMPVehicleOnSpawned(gameVehicleID)
	end
end

local function processPendingVehicleSpawnChecks()
	for gameVehicleID, frames in pairs(pendingVehicleSpawnChecks) do
		local veh = be:getObjectByID(gameVehicleID)
		if not veh then
			pendingVehicleSpawnChecks[gameVehicleID] = nil
		elseif frames > 0 then
			pendingVehicleSpawnChecks[gameVehicleID] = frames - 1
		else
			pendingVehicleSpawnChecks[gameVehicleID] = nil
			if isDeferredLocalCareerVehicle(gameVehicleID, veh) then
				log('D', 'careerMP.traffic', 'Keeping deferred Career vehicle local: ' .. tostring(gameVehicleID))
			elseif originalMPVehicleOnSpawned then
				prepareLocalVehicleForBeamMP(veh)
				originalMPVehicleOnSpawned(gameVehicleID)
			end
		end
	end
end

local function patchBeamMP()
	local beamMPExtension = beammp_multiplayer or multiplayer_multiplayer
	if beamMPExtension then
		if beamMPExtension.onUpdate ~= modifiedOnUpdate then
			originalMPOnUpdate = beamMPExtension.onUpdate
			beamMPExtension.onUpdate = modifiedOnUpdate
		end
	end
	if MPVehicleGE and MPVehicleGE.onVehicleSpawned ~= careerMPVehicleSpawnFilter then
		originalMPVehicleOnSpawned = MPVehicleGE.onVehicleSpawned
		MPVehicleGE.onVehicleSpawned = careerMPVehicleSpawnFilter
	end
	-- BeamMP broadcasts ping updates to every BeamNG vehicle, including Career
	-- traffic that intentionally has no BeamMP vehicle extensions. Guarding the
	-- vehicle-side call prevents one Lua error per traffic vehicle per second.
	if positionGE and positionGE.setPing and not originalMPPositionSetPing then
		originalMPPositionSetPing = positionGE.setPing
		positionGE.setPing = function(ping)
			local p = (tonumber(ping) or 0) / 1000
			for i = 0, be:getObjectCount() - 1 do
				local veh = be:getObject(i)
				if veh then
					veh:queueLuaCommand('if positionVE then positionVE.setPing(' .. tostring(p) .. ') end')
				end
			end
		end
	end
end

local function unPatchBeamMP()
	local beamMPExtension = beammp_multiplayer or multiplayer_multiplayer
	if beamMPExtension and originalMPOnUpdate then
		beamMPExtension.onUpdate = originalMPOnUpdate
	end
	if originalGetDriverData then
		core_camera.getDriverData = originalGetDriverData
	end
	if MPVehicleGE and originalMPVehicleOnSpawned then
		MPVehicleGE.onVehicleSpawned = originalMPVehicleOnSpawned
		originalMPVehicleOnSpawned = nil
	end
	if positionGE and originalMPPositionSetPing then
		positionGE.setPing = originalMPPositionSetPing
		originalMPPositionSetPing = nil
	end
end

--Initial Syncs and Updates

local function actionsCheck()
	if not clientConfig.consoleEnabled then
		table.insert(blockedInputActions, "toggleConsoleNG")
		extensions.core_input_actionFilter.setGroup('careerMP', blockedInputActions)
		extensions.core_input_actionFilter.addAction(0, 'careerMP', true)
	elseif clientConfig.consoleEnabled then
		extensions.core_input_actionFilter.setGroup('careerMP', blockedInputActions)
		extensions.core_input_actionFilter.addAction(0, 'careerMP', false)
	end
	if not clientConfig.worldEditorEnabled then
		table.insert(blockedInputActions, "editorToggle")
		table.insert(blockedInputActions, "editorSafeModeToggle")
		table.insert(blockedInputActions, "objectEditorToggle")
		extensions.core_input_actionFilter.setGroup('careerMP', blockedInputActions)
		extensions.core_input_actionFilter.addAction(0, 'careerMP', true)
	elseif clientConfig.worldEditorEnabled then
		extensions.core_input_actionFilter.setGroup('careerMP', blockedInputActions)
		extensions.core_input_actionFilter.addAction(0, 'careerMP', false)
	end
end

local function settingsCheck()
	careerMPTrafficSettings.trafficAllowMods = clientConfig.trafficAllowMods
	careerMPTrafficSettings.trafficSimpleVehicles = clientConfig.trafficSimpleVehicles
	careerMPTrafficSettings.trafficSmartSelections = clientConfig.trafficSmartSelections
	setTrafficSettings(careerMPTrafficSettings)
	careerMPGameplaySettings.simplifyRemoteVehicles = clientConfig.simplifyRemoteVehicles
	careerMPGameplaySettings.spawnVehicleIgnitionLevel = clientConfig.spawnVehicleIgnitionLevel
	careerMPGameplaySettings.skipOtherPlayersVehicles = clientConfig.skipOtherPlayersVehicles
	setGameplaySettings(careerMPGameplaySettings)
end

local function sanitizeProfileName(rawName)
	-- BeamNG stores profile folders as lowercase ASCII letters/numbers. Passing
	-- the unsanitized display name on later joins makes setProfile miss the
	-- existing folder and silently create name2/name3 duplicates.
	local profileName = string.lower(tostring(rawName or "")):gsub("[^a-z0-9]", "")
	if profileName == "" then
		profileName = "careermpprofile"
	end
	return profileName
end

local function profileExists(profileName)
	for _, existingProfile in ipairs(career_saveSystem.getAllProfiles() or {}) do
		if existingProfile == profileName then
			return true
		end
	end
	return false
end

local function rxCareerSync(data)
	clientConfig = jsonDecode(data)
	nickname = MPConfig.getNickname()
	blockedInputActions = {}
	settingsCheck()
	actionsCheck()
	applyGhostSettings()
	if not careerMPActive then
		careerMPActive = true
		local profileName
		if clientConfig.serverSaveNameEnabled then
			profileName = sanitizeProfileName(
				tostring(clientConfig.serverSaveName or "") .. tostring(clientConfig.serverSaveSuffix or "")
			)
		end
		if profileName then
			-- Existing profiles already contain their chosen career path. Passing
			-- freshStart here overwrites APM checkpoint recovery on every reconnect.
			local startingOptions = nil
			if not profileExists(profileName) then
				startingOptions = {startMode = "freshStart"}
			end
			local started = career_career.createOrLoadCareerAndStart(
				profileName,
				false,
				startingOptions
			)
			if not started then
				careerMPActive = false
				log('E', 'careerMP', 'Unable to load the selected CareerMP profile')
			end
		else
			extensions.ui_router.navigate("career.profiles")
			log('I', 'careerMP.profile', 'Waiting for the player to select a local Career profile')
		end
	end
end

local function rxClientConfigUpdate(data)
	clientConfig = jsonDecode(data)
	blockedInputActions = {}
	settingsCheck()
	actionsCheck()
	applyGhostSettings()
end

local function onCareerActive(active)
	if active and careerMPActive then
		if career_career and career_career.tutorialEnabled == true then
			local _, savePath = career_saveSystem.getCurrentProfile()
			pendingTutorialRestore = (savePath and jsonReadFile(savePath .. tutorialWorldStateFile)) or {}
			local tutorialState = savePath and jsonReadFile(savePath .. "/career/tutorialState.json") or {}
			pendingTutorialRestore.stepId = pendingTutorialRestore.stepId or tutorialState.currentStepId
		else
			pendingTutorialRestore = nil
		end
		local vehicles = MPVehicleGE.getVehicles()
		for _, vehicle in pairs(vehicles) do
			if vehicle.isLocal then
				if vehicle.jbeam ~= "unicycle" then
					be:getObjectByID(vehicle.gameVehicleID):delete()
				end
			end
		end
	end
end

local function onWorldReadyState(state)
	if state == 2 then
		applyGhostSettings()
		if not syncRequested then
			TriggerServerEvent("careerSyncRequested", "")
			syncRequested = true
		end
	end
end

local function onClientPostStartMission(levelPath)
	patchTopBar()
end

local function onUpdate(dtReal, dtSim, dtRaw)
	patchMissionStart()
	patchBeamMP()
	processPendingVehicleSpawnChecks()
	if pendingTutorialRestore and career_career and career_career.tutorialEnabled
		and gameplay_tutorial_setup and gameplay_tutorial_setup.vehicleSetupComplete then
		local tutorialVehId = gameplay_tutorial_setup.tutorialVehicleId
		local tutorialVeh = tutorialVehId and getObjectByID(tutorialVehId) or nil
		if tutorialVeh then
			local state = pendingTutorialRestore
			local pos, rot
			if type(state.vehiclePosition) == "table" then
				pos = vec3(state.vehiclePosition[1], state.vehiclePosition[2], state.vehiclePosition[3])
			end
			if type(state.vehicleRotation) == "table" then
				rot = quat(state.vehicleRotation[1], state.vehicleRotation[2], state.vehicleRotation[3], state.vehicleRotation[4])
			end
			if not pos and state.stepId == "08driveToGarage" and gameplay_tutorial_setup.tutorialSites then
				local spot = gameplay_tutorial_setup.tutorialSites.parkingSpots.byName["driveToGarageReset1"]
				if spot then pos, rot = spot.pos, spot.rot end
			end
			if pos then spawn.safeTeleport(tutorialVeh, pos, rot, nil, nil, nil, nil, false) end
			core_vehicleBridge.executeAction(tutorialVeh, "setFreeze", false)
			core_vehicleBridge.executeAction(tutorialVeh, "setIgnitionLevel", 2)
			if state.walking and type(state.playerPosition) == "table" then
				gameplay_walk.setWalkingMode(true)
				local player = getPlayerVehicle(0)
				if player then
					spawn.safeTeleport(player, vec3(state.playerPosition[1], state.playerPosition[2], state.playerPosition[3]), nil, nil, nil, nil, nil, false)
				end
			else
				gameplay_walk.getInVehicle(tutorialVeh)
			end
			local stepId = state.stepId
			pendingTutorialRestore = nil
			if stepId and career_modules_tutorial and career_modules_tutorial.activateStep then
				career_modules_tutorial.activateStep(stepId)
			end
			-- Rebuilding the tutorial runtime recreates the initial action filters.
			-- Restore the controls unlocked by the completed driving/map lessons.
			if gameplay_tutorial_setup then
				if gameplay_tutorial_setup.unblockGearActions then
					gameplay_tutorial_setup.unblockGearActions()
				end
				if stepId == "08driveToGarage" or stepId == "09spmSignup" then
					gameplay_tutorial_setup.blockedActionsTemplates.bigMap = false
				end
				gameplay_tutorial_setup.setupBlockedActions()
			end
			log('I', 'careerMP.tutorial', 'Restored tutorial world state for step ' .. tostring(stepId))
		end
	end
end

--Loading / Unloading

local function onExtensionLoaded()
	getUserTrafficSettings()
	getUserGameplaySettings()
	AddEventHandler("rxCareerSync", rxCareerSync)
	AddEventHandler("rxClientConfigUpdate", rxClientConfigUpdate)
	AddEventHandler("rxCareerVehSync", rxCareerVehSync)
	AddEventHandler("rxTrafficSignalTimer", rxTrafficSignalTimer)
	career_career = extensions.career_careerMP
	patchMissionStart()
	log('W', 'careerMP', 'CareerMP Enabler LOADED!')
end

local function onExtensionUnloaded()
	log('W', 'careerMP', 'CareerMP Enabler UNLOADED!')
end

local function onServerLeave()
	if career_career and career_career.isActive and career_career.isActive()
		and career_career.deactivateCareer then
		career_career.deactivateCareer(false)
	end
	careerMPActive = false
	syncRequested = false
	inComputerMenus = false
	unPatchBeamMP()
	blockedInputActions = {}
	extensions.core_input_actionFilter.setGroup('careerMP', blockedInputActions)
	extensions.core_input_actionFilter.addAction(0, 'careerMP', false)
	setTrafficSettings(userTrafficSettings)
	setGameplaySettings(userGameplaySettings)
end

local function onSaveCurrentProfile(currentSavePath)
	-- The CareerMP career controller uses a separate extension name from the
	-- stock controller. Explicitly persist its general metadata so named Save As
	-- slots retain their start mode and tutorial state across profile switches.
	if career_career and career_career.isActive and career_career.isActive()
		and career_career.onSaveCurrentProfile then
		career_career.onSaveCurrentProfile(currentSavePath)
	end
	if career_career and career_career.tutorialEnabled == true and gameplay_tutorial_setup then
		local tutorialVehId = gameplay_tutorial_setup.tutorialVehicleId
		local tutorialVeh = tutorialVehId and getObjectByID(tutorialVehId) or nil
		local playerVeh = getPlayerVehicle(0)
		local state = {
			stepId = career_modules_tutorial and career_modules_tutorial.getCurrentStep and career_modules_tutorial.getCurrentStep(),
			walking = gameplay_walk and gameplay_walk.isWalking and gameplay_walk.isWalking() or false
		}
		if tutorialVeh then
			local p = tutorialVeh:getPosition()
			local r = tutorialVeh:getRotation()
			state.vehiclePosition = {p.x, p.y, p.z}
			state.vehicleRotation = {r.x, r.y, r.z, r.w}
		end
		if playerVeh then
			local p = playerVeh:getPosition()
			state.playerPosition = {p.x, p.y, p.z}
		end
		career_saveSystem.jsonWriteFileSafe(currentSavePath .. tutorialWorldStateFile, state, true)
	end
end

--Access

M.getClientConfig = getClientConfig

M.onCareerActive = onCareerActive
M.onSaveCurrentProfile = onSaveCurrentProfile

M.onVehicleActiveChanged = onVehicleActiveChanged
M.onVehicleSpawned = onVehicleSpawned
M.onVehicleReady = onVehicleReady
M.onVehicleSwitched = onVehicleSwitched

M.onSpeedTrapTriggered = onSpeedTrapTriggered
M.onRedLightCamTriggered = onRedLightCamTriggered

M.onComputerOpened = onComputerOpened
M.onComputerMenuOpened = onComputerOpened

M.onCareerTuningStarted = computerMenuHandler
M.onPartShoppingStarted = computerMenuHandler
M.onPerformanceTestStarted = computerMenuHandler
M.onVehiclePaintingUiOpened = computerMenuHandler

M.onClientPostStartMission = onClientPostStartMission

M.preStageLightOn = preStageLightOn
M.stageLightOn = stageLightOn
M.stoppingVehicleDrag = stoppingVehicleDrag
M.onDragRacersSetup = onDragRacersSetup

M.onWorldReadyState = onWorldReadyState
M.onUpdate = onUpdate

M.onExtensionLoaded = onExtensionLoaded
M.onExtensionUnloaded = onExtensionUnloaded

M.onServerLeave = onServerLeave
M.onBeamMPServerLeave = onServerLeave

M.onInit = function() setExtensionUnloadMode(M, 'manual') end

return M
